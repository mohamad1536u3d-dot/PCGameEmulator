package com.example.pcgameemulator

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val gamesDir by lazy { File(filesDir, "games").apply { mkdirs() } }
    private val pickExe = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF2F5FA.toInt())
        }

        val title = TextView(this).apply {
            text = "PC Game Emulator"
            textSize = 25f
            setTextColor(0xFF123B66.toInt())
            setPadding(0, 0, 0, 8)
        }
        page.addView(title)

        val subtitle = TextView(this).apply {
            text = "مكتبة ألعاب الكمبيوتر"
            textSize = 16f
            setTextColor(0xFF444444.toInt())
        }
        page.addView(subtitle)

        val add = Button(this).apply {
            text = "＋ استيراد ملف لعبة EXE"
            setOnClickListener { openPicker() }
        }
        page.addView(add)

        status = TextView(this).apply {
            text = "استورد ملفات الألعاب لتظهر هنا."
            textSize = 14f
            setPadding(0, 16, 0, 12)
            setTextColor(0xFF555555.toInt())
        }
        page.addView(status)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val note = TextView(this).apply {
            text = "تنبيه: هذه نسخة واجهة ومكتبة ملفات. محرك Wine/Box64 غير مدمج، لذلك لا تشغّل ألعاب Windows بعد."
            textSize = 12f
            setTextColor(0xFF8A3B00.toInt())
            setPadding(0, 14, 0, 0)
        }
        page.addView(note)

        setContentView(page)
        refreshGames()
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, pickExe)
    }

    @Deprecated("Uses the document picker result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickExe || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val displayName = queryName(uri) ?: "game_${System.currentTimeMillis()}.exe"
            val safeName = displayName.replace(Regex("[^A-Za-z0-9._ -]"), "_")
            val destination = File(gamesDir, safeName)
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "تعذر فتح الملف" }.use { source ->
                    destination.outputStream().use { output -> source.copyTo(output) }
                }
            }
            status.text = "تم استيراد: $safeName"
            refreshGames()
        } catch (e: Exception) {
            status.text = "فشل استيراد الملف: ${e.message ?: "خطأ غير معروف"}"
        }
    }

    private fun queryName(uri: Uri): String? {
        val cursor = contentResolver.query(uri, null, null, null, null) ?: return null
        cursor.use {
            val index = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            return if (it.moveToFirst() && index >= 0) it.getString(index) else null
        }
    }

    private fun refreshGames() {
        list.removeAllViews()
        val games = gamesDir.listFiles()?.sortedBy { it.name.lowercase() } ?: emptyList()
        if (games.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا توجد ألعاب مستوردة."
                textSize = 15f
                setPadding(0, 12, 0, 12)
            })
            return
        }
        games.forEach { file ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(16, 14, 16, 14)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            row.addView(TextView(this).apply {
                text = file.name
                textSize = 16f
                setTextColor(0xFF222222.toInt())
            })
            row.addView(Button(this).apply {
                text = "تشغيل"
                setOnClickListener {
                    Toast.makeText(
                        this@MainActivity,
                        "محرك Wine/Box64 غير مدمج في هذه النسخة بعد.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = 12
            })
        }
    }
}
